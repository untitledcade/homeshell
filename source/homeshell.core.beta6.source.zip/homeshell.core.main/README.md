# homeshell.core.main
Homeshell.core.main is a open sourced program designed to combine essential programs into one lightweight program. It combines a webbrowser for connecting to the internet, a word processor for quick notes and documents like reports and essays, a social fourm for posting content, and support for 3rd party apps. 
