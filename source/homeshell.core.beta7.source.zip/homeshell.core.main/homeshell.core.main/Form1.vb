﻿Public Class Form1

#Region "Programs"

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        frmMain.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        WebBrowser.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dialog1.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AppLoader.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Tonline.Show()
    End Sub

#End Region

    'Open Homeshell Programs

#Region "Options"

    Private Sub UpdatesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdatesToolStripMenuItem.Click
        Updatehs.Show()
    End Sub

    Private Sub FeedbackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FeedbackToolStripMenuItem.Click
        Feedback.Show()
    End Sub

#End Region

    'This is for the Options Menu on the Tool Strip

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        TimerText.Text = DateTime.Now.ToString("hh:mm tt")
        DaterText.Text = DateTime.Now.ToString("MM/dd/yyyy")

    End Sub





    'Real Time Clock

End Class