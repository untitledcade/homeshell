﻿Public NotInheritable Class SplashScreen1
    Private Sub SplashScreen1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
