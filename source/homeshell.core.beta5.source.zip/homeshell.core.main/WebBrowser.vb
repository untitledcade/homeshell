﻿

Public Class WebBrowser

#Region "WebBoxToolStripMenu"


    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dialog1.ShowDialog()
    End Sub

    Private Sub GiveFeedbackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GiveFeedbackToolStripMenuItem.Click
        Feedback.Show()
    End Sub

#End Region

    'This is for the WebBox Menu on the Tool Strip

End Class