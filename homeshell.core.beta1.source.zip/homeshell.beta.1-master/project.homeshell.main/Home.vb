﻿
Public Class Form1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = Format(Now, "hh:mm")
        Label2.Text = Format(Now, "dd-MM-yyyy")

    End Sub
End Class
