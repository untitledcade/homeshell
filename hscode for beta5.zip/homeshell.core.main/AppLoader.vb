﻿Public Class AppLoader


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Process.Start("explorer.exe", "C:\Homeshell\AppShortcuts")
    End Sub

    'Open the Directory for Homeshell Apps (Opens Explorer to Directory C:\Homeshell\AppShortcuts)


End Class